package com.likelion.timer.challenge.DTO;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChallengeViewStep2Dto {
    private String title;
    private String authMethod;
    private String endDate;
    private String note;
}
