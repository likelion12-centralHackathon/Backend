package com.likelion.timer.challenge.domain.entity;

public enum Category {
    DEVELOPMENT,
    FREE,
    HEALTH
}

